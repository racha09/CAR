<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "vms";
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Vérification si l'ID de l'enregistrement à éditer est spécifié en paramètre d'URL
if(isset($_GET["id"])){
    $id = $_GET["id"];
    
    // Requête SQL pour sélectionner l'enregistrement correspondant à l'ID
    $sql = "SELECT * FROM drivers  WHERE id=$id";
    $result = $conn->query($sql);

    // Vérification si l'enregistrement existe
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $name = $row["name"];
        $mobile = $row["mobile"];
         $age = $row["age"];
        $address = $row["address"];
        $status = $row["status"];

        
    } else {
        echo "Enregistrement non trouvé";
        exit;
    }
} else {
    echo "ID de l'enregistrement non spécifié";
    exit;
}

// Traitement du formulaire d'édition lorsque l'utilisateur soumet le formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $mobile = $_POST["mobile"];
    $age = $_POST["age"];
    $address = $_POST["address"];
    @$status = $_POST["status"];

    // Requête SQL pour mettre à jour l'enregistrement dans la base de données
    $sql = "UPDATE drivers SET name='$name', mobile='$mobile', age='$age', address='$address', status='$status' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "Enregistrement mis à jour avec succès";
    } else {
        echo "Erreur lors de la mise à jour de l'enregistrement: " . $conn->error;
    }
}

// Fermeture de la connexion
$conn->close();
?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">


<!-- Affichage du formulaire d'édition -->
<form action="" method="post" class="container mt-5">
    <div class="mb-3">
        <label for="name" class="form-label">Name:</label>
        <input type="text" name="name" id="name" class="form-control W-50" value="<?php echo $name; ?>">
    </div>
    <div class="mb-3">
        <label for="mobile" class="form-label">Mobile:</label>
        <input type="text" name="mobile" id="mobile" class="form-control W-50" value="<?php echo $mobile; ?>">
    </div>
    <div class="mb-3">
        <label for="age" class="form-label">Age:</label>
        <input type="age" name="age" id="age" class="form-control W-50" value="<?php echo $age; ?>">
    </div>
    <div class="mb-3">
        <label for="address" class="form-label">Adress:</label>
        <input type="address" name="address" id="address" class="form-control W-50" value="<?php echo $address; ?>">
    </div>
    <div class="mb-3">
        <label for="status" class="form-label">Status:</label>
        <select id="status" name="status" class="form-control W-50" value="<?php echo $status; ?>">
            <option value="" disabled selected>-- Sélectionnez une option --</option>
            <option value="active">Actif</option>
            <option value="inactive">Inactif</option>
        </select>
    </div>
    
    
    <input type="submit" value="Enregistrer" class="btn btn-primary mt-3">
</form>


