<?php// Inclure le fichier d'autoloader de PHPSpreadsheet
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

// Connexion à la base de données
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'vms';

$conn = mysqli_connect($host, $username, $password, $dbname);

if (!$conn) {
    die("La connexion à la base de données a échoué : " . mysqli_connect_error());
}

// Lecture du fichier Excel
$filename = '/dashboard/report (3).xlsx';

$spreadsheet = IOFactory::load($filename);

$worksheet = $spreadsheet->getActiveSheet();

// Récupération des données et insertion dans la base de données
foreach ($worksheet->getRowIterator() as $row) {
    $cellIterator = $row->getCellIterator();
    $cellIterator->setIterateOnlyExistingCells(false);
    $values = [];

    foreach ($cellIterator as $cell) {
        $values[] = $cell->getValue();
    }

    $query = "INSERT INTO place (Valide, Time, Latitude, Longitude, Altitude, Speed, Address, Attributes) VALUES (?s, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ssssssss", $values[0], $values[1], $values[2], $values[3], $values[4], $values[5], $values[6], $values[7]);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

// Fermeture de la connexion à la base de données
mysqli_close($conn);
?>
