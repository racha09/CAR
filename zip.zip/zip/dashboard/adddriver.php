<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "vms";

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
  }
  if ($_SERVER["REQUEST_METHOD"]=="POST") {
  // Récupération des données du formulaire
  
  $name = $_POST['name'];
  $mobile = $_POST['mobile'];
  $age = $_POST['age'];
  $address = $_POST['address'];
  $status = $_POST['status'];
  
  // Préparation de la requête SQL pour l'insertion ou la mise à jour des données
  
      $sql = "INSERT INTO drivers (name, mobile, age, address, status) VALUES ('$name', '$mobile', '$age', '$address', '$status')";

   

    
     
  // Exécution de la requête SQL
  if ($conn->query($sql) === TRUE) {
    echo "Les données du conducteur ont été enregistrées avec succès.";
  } else {
    echo "Erreur : " . $sql . "<br>" . $conn->error;
  }
  
  }
  
  // Fermeture de la connexion à la base de données
  $conn->close();
  ?>
  
  
  <!DOCTYPE html>
<html>
<head>
    <title>Ajouter/Modifier un conducteur</title>
    <style>
        * {
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
      
        .cont {
            max-width: 600px;
            margin: 0 50px;
            padding: 20px;
            background-color: #f4f4f4;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, select, textarea {
            width: 70%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        input[type=submit] {
            background-color: blue;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            padding: 8px;
            font-size: 16px;
        }
        input[type=submit]:hover {
            background-color: blue;
        }
    </style>
</head>
<body>
<div class="cont mt-5">
        <h1>Add driver</h1>
        <form action="" method="post">
           <!-- <label for="id">Id :</label>
            <input type="text" id="id" name="id" readonly>-->
    
            <label for="name">Nom :</label>
            <input type="text" id="name" name="name" required>
    
            <label for="mobile">Numéro de téléphone portable :</label>
            <input type="text" id="mobile" name="mobile" required>
    
            <label for="age">Âge :</label>
            <input type="text" id="age" name="age" required>
    
            <label for="address">Adresse :</label>
            <textarea id="address" name="address" required></textarea>
    
            <label for="status">Statut :</label>
            <select id="status" name="status">
    <option value="" disabled selected>-- Sélectionnez une option --</option>
    <option value="active">Actif</option>
    <option value="inactive">Inactif</option>
</select>

    
            <input type="submit" value="Enregistrer">
        </form>
</div>
</body>
</html>
