

<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
	
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	
	<style>
		.icon {
			font-size: 5em;
			margin-bottom: 0.5em;
		}
		.driver-icon {
			background-color: #007bff;
			display: inline-block;
			width: 37.5px;
			height: 30px;
			margin-right: 0.5em;
			vertical-align: middle;
			text-align: center;
			line-height: 30px;
			font-size: 1.5em;
			color: #fff;
		}
		.vehicle-icon {
			background-color: #28a745;
			display: inline-block;
			width: 37.5px;
			height: 30px;
			margin-right: 0.5em;
			vertical-align: middle;
			text-align: center;
			line-height: 30px;
			font-size: 1.5em;
			color: #fff;
		}
		.search-box {
			max-width: 250px;
			margin-bottom: 10px;
		}
		.chart-container {
   max-width: 600px;
}

	</style>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6">
				<div class="card text-center">
					<div class="card-body">
						<h5 class="card-title">Total Drivers</h5>
						<span class="icon driver-icon"><i class="fas fa-user"></i></span>
						<!--<p class="card-text">10</p> -->
					</div>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="card text-center">
					<div class="card-body">
						<h5 class="card-title">Total Vehicles</h5>
						<span class="icon vehicle-icon"><i class="fas fa-truck text-white"></i></span>
						<!--<p class="card-text">20</p> -->
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<div class="card">
					<div class="card-header">
						Current Location of Vehicles
					</div>
					<div class="card-body">
						<div class="input-group search-box">
							<input type="text" class="form-control" placeholder="Search for a vehicle...">
							<div class="input-group-append">
								<button class="btn btn-primary" type="button">
									<i class="fas fa-search"></i>
								</button>
							</div>
						</div>
						<table class="table">
							<thead>
								<tr>
									<th scope="col">#</th>
									<th scope="col">Vehicle Name</th>
									<th scope="col">Current Location</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<th scope="row">1</th>
									<td>Vehicle 1</td>
									<td>Location 1</td>
								</tr>
							</tbody>
						</table>

					</div>
				</div>
			</div>
		</div>
		
	<div class="canvas-container chart-container">
		<canvas id="myChart"></canvas>
	</div>

	<script>
		var ctx = document.getElementById('myChart').getContext('2d');
		var myChart = new Chart(ctx, {
		    type: 'line',
		    data: {
		        labels: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet'],
		        datasets: [{
		            label: 'Nombre de Véhicules',
		            data: [12, 19, 3, 5, 2, 3, 9],
		            borderColor: 'rgb(255, 99, 132)',
		            borderWidth: 2
		        }]
		    },
		    options: {
		        scales: {
		            yAxes: [{
		                ticks: {
		                    beginAtZero: true
		                }
		            }]
		        }
		    }
		});
	</script>
</body>
</html>






		



								

