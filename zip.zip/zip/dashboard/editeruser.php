

<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "vms";
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Vérification si l'ID de l'enregistrement à éditer est spécifié en paramètre d'URL
if(isset($_GET["id"])){
    $id = $_GET["id"];
    
    // Requête SQL pour sélectionner l'enregistrement correspondant à l'ID
    $sql = "SELECT * FROM users WHERE id=$id";
    $result = $conn->query($sql);

    // Vérification si l'enregistrement existe
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $username = $row["username"];
        $email = $row["email"];
        $password = $row["password"];
       
    } else {
        echo "Enregistrement non trouvé";
        exit;
    }
} else {
    echo "ID de l'enregistrement non spécifié";
    exit;
}

// Traitement du formulaire d'édition lorsque l'utilisateur soumet le formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    

    // Requête SQL pour mettre à jour l'enregistrement dans la base de données
    $sql = "UPDATE users SET username='$username', email='$email', password='$password' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "Enregistrement mis à jour avec succès";
    } else {
        echo "Erreur lors de la mise à jour de l'enregistrement: " . $conn->error;
    }
}

// Fermeture de la connexion
$conn->close();
?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">


<!-- Affichage du formulaire d'édition -->
<form action="" method="post" class="container mt-5">
    <div class="mb-3">
        <label for="username" class="form-label">Username:</label>
        <input type="text" name="username" id="username" class="form-control W-50" value="<?php echo $username; ?>">
    </div>
    <div class="mb-3">
        <label for="email" class="form-label">Email:</label>
        <input type="text" name="email" id="email" class="form-control W-50" value="<?php echo $email; ?>">
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Password:</label>
        <input type="password" name="password" id="password" class="form-control W-50" value="<?php echo $password; ?>">
    </div>
    
    <input type="submit" value="Enregistrer" class="btn btn-primary mt-3">
</form>

