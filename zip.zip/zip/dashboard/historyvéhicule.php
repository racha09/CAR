<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "vms";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Erreur de connexion à la base de données: " . $e->getMessage();
}

// Traitement du formulaire de recherche
if (isset($_POST['search'])) {
    $search = $_POST['search'];

    // Requête SQL pour rechercher les détails du véhicule
    $stmt = $conn->prepare("SELECT * FROM cars WHERE name = :search");
    $stmt->bindParam(':search', $search);
  
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Affichage du formulaire
?>
<form method="post">
    <label for="search">Recherche de véhicule:</label>
    <input type="text" name="search" id="search">
    <button type="submit">Rechercher</button>
</form>

<?php
// Affichage des détails du véhicule trouvé
if (isset($result)) {
    echo "<h2>Résultats de la recherche</h2>";
    echo "<ul>";
    echo "<li>matricule: " . $result['matricule-v'] . "</li>";
    echo "<li>position: " . $result['position-v'] . "</li>";
    echo "<li>name: " . $result['nom-v'] . "</li>";
    echo "</ul>";
}
?>



